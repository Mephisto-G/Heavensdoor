from tkinter import *
import os
import hashlib
import time
from pyfingerprint.pyfingerprint import PyFingerprint

def main_screen():
  global screen2
  screen2 = Tk()
  screen2.title("Start Security")
  screen2.geometry("250x200")

  global username_verify
  global password_verify

  username_verify = StringVar()
  password_verify = StringVar()

  global username_entry1
  global password_entry1

  Label(screen2, text = "Usuario ").pack()
  username_entry1 = Entry(screen2, textvariable = username_verify)
  username_entry1.pack()
  Label(screen2, text = "").pack()
  Label(screen2, text = "Senha ").pack()
  password_entry1 = Entry(screen2, textvariable = password_verify, show = "***")
  password_entry1.pack()
  Label(screen2, text = "").pack()
  Button(screen2, text = "Login", width = 10, height = 1, command = login_verify).pack()

  screen2.mainloop()

def busca():
	## Tries to initialize the sensor
	try:
		f = PyFingerprint('/dev/ttyUSB0', 57600, 0xFFFFFFFF, 0x00000000)

		if ( f.verifyPassword() == False ):
			raise ValueError('The given fingerprint sensor password is wrong!')

	except Exception as e:
		print('The fingerprint sensor could not be initialized!')
		print('Exception message: ' + str(e))
		exit(1)
		## Tries to search the finger and calculate hash
	try:
		print('Waiting for finger...')

    ## Wait that finger is read
		while ( f.readImage() == False ):
			pass

    ## Converts read image to characteristics and stores it in charbuffer 1
		f.convertImage(0x01)

    ## Searchs template
		result = f.searchTemplate()
	
		positionNumber = result[0]
		accuracyScore = result[1]

		if ( positionNumber == 0 ):
			print('Match!')
			exit(0)
		else:
			print('Found template at position #' + str(positionNumber))
			print('The accuracy score is: ' + str(accuracyScore))

		
		
		
		


def login_verify():

  username1 = username_verify.get()
  password1 = password_verify.get()
  username_entry1.delete(0, END)
  password_entry1.delete(0, END)

  list_of_files = os.listdir()
  if username1 in list_of_files:
    file1 = open(username1, "r")
    verify = file1.read().splitlines()
    
    if password1 in verify:
        home()
    else:
        password_not_recognised()

  else:
        user_not_found()
