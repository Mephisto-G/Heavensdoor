from tkinter import *
import time
import hashlib
import os
from pyfingerprint.pyfingerprint import PyFingerprint

def msg6():
    global screen2
    screen2 = Toplevel(Tela)
    screen2.attributes('-fullscreen',True)
    Label(screen2, text = 'Error', font = "Arial 12").pack()

def msg5():
    global screen1
    screen1 = Toplevel(Tela)
    screen1.attributes('-fullscreen',True)
    Label(screen1, text = 'cadastrado', font = "Arial 12").pack()

def msg4():
    global screen3
    screen3 = Toplevel(Tela)
    screen3.attributes('-fullscreen',True)
    Label(screen3, text = 'dedo ja cadastrado', font = "Arial 12").pack()

def msg1():
    global screen4
    screen4 = Toplevel(Tela)
    screen4.attributes('-fullscreen',True)
    Label(screen4, text = 'Insira o dedo', font = "Arial 12").pack()


def msg2():
    global screen5
    screen5 = Toplevel(Tela)
    screen5.attributes('-fullscreen',True)
    Label(screen5, text = 'Remova', font = 'Arial 12').pack()


def msg3():
    global screen6
    screen6 = Toplevel(Tela)
    screen6.attributes('-fullscreen',True)
    Label(screen6, text = 'Insira o mesmo dedo', font = "Arial 12").pack()


def Menu():
    global Tela
    Tela=Tk()
    Tela.title('bio')
    Tela.attributes('-fullscreen', True)
    Label(Tela, text = 'Iniciando...', font = "Arial 12").pack()
    try:
        f = PyFingerprint('/dev/ttyUSB0', 57600, 0xFFFFFFFF, 0x00000000)
        if ( f.verifyPassword() == False ):
            raise ValueError('The given fingerprint sensor password is wrong!')
    except Exception as e:
        Adicionar_Digital()

    Tela.mainloop()

def Adicionar_Digital():
    try:
        msg1()
        while(f.readImage() == False):
            pass
        f.convertImage(0x01)
        result=f.searchTemplate()
        positionNumber= result[0]
        if (positionNumber >= 0):
            msg4()
            exit(0)

        msg2()
        time.sleep(2)

        msg3()
        
        while ( f.readImage() == False ):
            pass
        f.convertImage(0x02)
        if ( f.compareCharacteristics() == 0 ):
            raise Exception ('Fingers do not match')
        f.createTemplate()
        msg5()
    except Exception as e:
        print('Operation failed!')
        print('Exception message: ' + str(e))
        exit(0)
Menu()
