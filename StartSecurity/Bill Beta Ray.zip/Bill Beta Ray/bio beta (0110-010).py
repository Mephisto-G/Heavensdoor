from tkinter import *
import time
import hashlib
import os
from pyfingerprint.pyfingerprint import PyFingerprint

def labelIniciando():
	inicio = Label(Tela, text = 'Iniciando')
	inicio.pack()
	Tela.after(1000, labelRemover)
def labelAdicione():
	insira = Label(Tela, text = 'Insira')
	insira.pack()
def labelRemover():
	rem = Label(Tela, text = 'Remova')
	rem.pack()
def labelSucesso():
	rem = Label(Tela, text = 'Sucesso')
	rem.pack()



def Adicionar_Digital():
    global Tela
    Tela=Tk()
    Tela.title('bio')
    Tela.attributes('-fullscreen', True)
    Label(Tela, text = 'Iniciando...', font = 'Arial 12').pack()
    Tela.Mainloop()
    Tela.after(1000, addigital)
def addigital():
    try:
        f = PyFingerprint('/dev/ttyUSB0', 57600, 0xFFFFFFFF, 0x00000000)
        if ( f.verifyPassword() == False ):
            raise ValueError('The given fingerprint sensor password is wrong!')
    except Exception as e:
        exit(1)
        Label(Tela, text = 'Insira o dedo', font = "Arial 12").pack()
        Tela.update_idletasks()
        Tela.update()
    try:
        print('botodeda1')
        Tela.after(1, labelAdicione)
        
        while(f.readImage() == False):
            pass
        f.convertImage(0x01)
        result=f.searchTemplate()
        positionNumber= result[0]
        if (positionNumber >= 0):
            print('já tem')
            exit(0)
            Tela.after(1, labelRemover)
            time.sleep(2)
            Tela.after(1, labelAdicione)
            
            Tela.update_idletasks()
            Tela.update()
        while ( f.readImage() == False ):
            pass
        f.convertImage(0x02)
        if ( f.compareCharacteristics() == 0 ):
            raise Exception('Fingers do not match')
        f.createTemplate()
        print('Finger enrolled successfully!')
        Tela.after(1, labelSucesso)
    except Exception as e:
        print('Operation failed!')
        print('Exception message: ' + str(e))
        exit(0)

    
Adicionar_Digital()
