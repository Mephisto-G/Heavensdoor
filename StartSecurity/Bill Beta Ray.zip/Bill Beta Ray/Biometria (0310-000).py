from tkinter import *
import time
import os
#from pyfingerprint.pyfingerprint import PyFingerprint



	
def Adicionar(self):
		
	Tela.after(1000, labelAdicione)
	Tela.after(1000, Adicionar)
	Tela.after(1000, labelRemover)
		#self.Adicionar()
def labelIniciando():
	inicio = Label(Tela, text = 'Iniciando')
	inicio.pack()
	Tela.after(1000, labelRemover)
def labelAdicione():
	insira = Label(Tela, text = 'Insira')
	insira.pack()
def labelRemover():
	rem = Label(Tela, text = 'Remova')
	rem.pack()

def parar():
	Tela.destroy()

Tela = Tk()
Tela.title = "Biometria"
Tela.attributes('-fullscreen', True)
Button(Tela, text = "Iniciar", command = Tela.after(1000, labelIniciando)).pack()
Button(Tela, text = "Parar", command = parar).pack()
Tela.mainloop()
		
