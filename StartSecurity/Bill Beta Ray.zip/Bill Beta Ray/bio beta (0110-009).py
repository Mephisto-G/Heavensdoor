from tkinter import *
import time
import hashlib
import os
from pyfingerprint.pyfingerprint import PyFingerprint


def msg1():
    global Tela1
    Tela1=Tk()
    Tela1.title('bio')
    Tela1.attributes('-fullscreen', True)
    Label(Tela1, text = 'Insira o dedo', font = "Arial 12").pack()
    Tela1.mainloop()
def msg2():
    global Tela2
    Tela2=Tk()
    Tela2.title('bio')
    Tela2.attributes('-fullscreen', True)
    Label(Tela2, text = 'Remova', font = 'Arial 12').pack()
    Tela1.mainloop()

def msg3():
    global Tela3
    Tela3=Tk()
    Tela3.title('bio')
    Tela3.attributes('-fullscreen', True)
    Label(Tela3, text = 'Insira o mesmo dedo', font = "Arial 12").pack()
    Tela1.mainloop()

  
def Menu():
    global Tela
    Tela=Tk()
    Tela.title('bio')
    Tela.attributes('-fullscreen', True)
    Label(Tela, text = 'Iniciando...', font = 'Arial 12').pack()
    a="a"
    if a == "a":
        Adicionar_Digital()
    else:
        exit(0)
    Tela.mainloop()
    
    
    


def Adicionar_Digital():
    try:
        f = PyFingerprint('/dev/ttyUSB0', 57600, 0xFFFFFFFF, 0x00000000)
        if ( f.verifyPassword() == False ):
            raise ValueError('The given fingerprint sensor password is wrong!')
    except Exception as e:
        exit(1)
        #Label(Tela, text = 'Insira o dedo', font = "Arial 12").pack()
        msg1()
    
    try:
        print('botodeda1')
        while(f.readImage() == False):
            pass
        f.convertImage(0x01)
        result=f.searchTemplate()
        positionNumber= result[0]
        if (positionNumber >= 0):
            print('já tem')	
            exit(0)
            #Label(Tela, text = 'Remova', font = 'Arial 12').pack()
            msg2()
            time.sleep(2)
            #Label(Tela, text = 'Insira o mesmo dedo', font = "Arial 12").pack()
            msg3()
        
        while ( f.readImage() == False ):
            pass
        f.convertImage(0x02)
        if ( f.compareCharacteristics() == 0 ):
            raise Exception('Fingers do not match')
        f.createTemplate()
        print('Finger enrolled successfully!')
        Label(Tela, text = 'Registrado!!!!!!!!', font = 'Arial 12').pack()
    except Exception as e:
        print('Operation failed!')
        print('Exception message: ' + str(e))
        exit(0)
Menu()

